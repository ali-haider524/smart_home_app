import 'channel_model.dart';
import 'schedule_model.dart';
import 'timer_model.dart';

class DeviceModel {
  final String id;
  final bool online;
  final int lastSeen;
  final String firmwareVersion;
  final String model;
  final int channelCount;
  final Map<String, ChannelModel> channels;
  final Map<String, TimerModel> timers;
  final Map<String, ScheduleModel> schedules;

  DeviceModel({
    required this.id,
    required this.online,
    required this.lastSeen,
    required this.firmwareVersion,
    required this.model,
    required this.channelCount,
    required this.channels,
    required this.timers,
    required this.schedules,
  });

  factory DeviceModel.fromMap(String id, Map<dynamic, dynamic> data) {
    final parsedChannels = <String, ChannelModel>{};
    final parsedTimers = <String, TimerModel>{};
    final parsedSchedules = <String, ScheduleModel>{};

    if (data['channels'] is Map) {
      Map<dynamic, dynamic>.from(data['channels']).forEach((key, value) {
        if (value is Map) {
          parsedChannels[key.toString()] =
              ChannelModel.fromMap(key.toString(), Map<dynamic, dynamic>.from(value));
        }
      });
    }

    if (data['timers'] is Map) {
      Map<dynamic, dynamic>.from(data['timers']).forEach((key, value) {
        if (value is Map) {
          parsedTimers[key.toString()] =
              TimerModel.fromMap(Map<dynamic, dynamic>.from(value));
        }
      });
    }

    if (data['schedules'] is Map) {
      Map<dynamic, dynamic>.from(data['schedules']).forEach((key, value) {
        if (value is Map) {
          parsedSchedules[key.toString()] =
              ScheduleModel.fromMap(Map<dynamic, dynamic>.from(value));
        }
      });
    }

    return DeviceModel(
      id: id,
      online: data['online'] == true,
      lastSeen: int.tryParse(data['lastSeen']?.toString() ?? '') ?? 0,
      firmwareVersion: data['firmwareVersion']?.toString() ?? 'Unknown',
      model: data['model']?.toString() ?? 'SW1',
      channelCount: int.tryParse(data['channelCount']?.toString() ?? '') ?? 1,
      channels: parsedChannels,
      timers: parsedTimers,
      schedules: parsedSchedules,
    );
  }

  bool get isOnline {
    if (online) return true;
    if (lastSeen <= 0) return false;

    final now = DateTime.now().millisecondsSinceEpoch;
    return now - lastSeen <= 10000;
  }

  String get nickname => 'Smart Switch';

  String get lastSeenText {
    if (lastSeen <= 0) {
      return isOnline ? 'Online now' : 'Never seen';
    }

    final now = DateTime.now().millisecondsSinceEpoch;
    final diffSeconds = ((now - lastSeen) / 1000).floor();

    if (diffSeconds < 5) return 'Just now';
    if (diffSeconds < 60) return '$diffSeconds sec ago';

    final minutes = (diffSeconds / 60).floor();
    if (minutes < 60) return '$minutes min ago';

    final hours = (minutes / 60).floor();
    if (hours < 24) return '$hours hr ago';

    final days = (hours / 24).floor();
    return '$days day ago';
  }
}