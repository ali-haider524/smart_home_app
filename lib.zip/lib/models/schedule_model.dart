class ScheduleModel {
  final bool enabled;

  final int onHour;
  final int onMinute;

  final int offHour;
  final int offMinute;

  const ScheduleModel({
    required this.enabled,
    required this.onHour,
    required this.onMinute,
    required this.offHour,
    required this.offMinute,
  });

  factory ScheduleModel.fromMap(Map<dynamic, dynamic> map) {
    return ScheduleModel(
      enabled: map['enabled'] == true,
      onHour: int.tryParse(map['onHour']?.toString() ?? '') ?? 0,
      onMinute: int.tryParse(map['onMinute']?.toString() ?? '') ?? 0,
      offHour: int.tryParse(map['offHour']?.toString() ?? '') ?? 0,
      offMinute: int.tryParse(map['offMinute']?.toString() ?? '') ?? 0,
    );
  }
}