class TimerModel {
  final bool enabled;
  final int durationMinutes;
  final String label;

  const TimerModel({
    required this.enabled,
    required this.durationMinutes,
    required this.label,
  });

  factory TimerModel.fromMap(Map<dynamic, dynamic> map) {
    return TimerModel(
      enabled: map['enabled'] == true,
      durationMinutes:
      int.tryParse(map['durationMinutes']?.toString() ?? '') ?? 0,
      label: map['label']?.toString() ?? '',
    );
  }
}