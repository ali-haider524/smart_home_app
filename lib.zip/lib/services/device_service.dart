import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

import '../models/device_model.dart';

class DeviceService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final FirebaseDatabase _database = FirebaseDatabase.instanceFor(
    app: Firebase.app(),
    databaseURL:
    'https://easyhomecontrol-1-default-rtdb.asia-southeast1.firebasedatabase.app',
  );

  DatabaseReference get _devicesRef => _database.ref('devices');
  DatabaseReference get _usersRef => _database.ref('users');

  String? get currentUid => _auth.currentUser?.uid;

  Stream<List<DeviceModel>> listenAllDevices() {
    final uid = currentUid;

    if (uid == null) {
      return Stream.value(<DeviceModel>[]);
    }

    final controller = StreamController<List<DeviceModel>>.broadcast();

    StreamSubscription<DatabaseEvent>? userDeviceSub;
    StreamSubscription<DatabaseEvent>? allDevicesSub;

    userDeviceSub = _usersRef.child(uid).child('devices').onValue.listen(
          (userEvent) {
        final userDeviceValue = userEvent.snapshot.value;

        final allowedDeviceIds = <String>{};

        if (userDeviceValue is Map) {
          final userDevices = Map<dynamic, dynamic>.from(userDeviceValue);

          userDevices.forEach((deviceId, value) {
            if (value is Map) {
              final deviceInfo = Map<dynamic, dynamic>.from(value);
              final active = deviceInfo['active'] != false;

              if (active) {
                allowedDeviceIds.add(deviceId.toString());
              }
            } else if (value == true) {
              allowedDeviceIds.add(deviceId.toString());
            }
          });
        }

        allDevicesSub?.cancel();

        if (allowedDeviceIds.isEmpty) {
          controller.add(<DeviceModel>[]);
          return;
        }

        allDevicesSub = _devicesRef.onValue.listen(
              (devicesEvent) {
            final devicesValue = devicesEvent.snapshot.value;

            if (devicesValue == null || devicesValue is! Map) {
              controller.add(<DeviceModel>[]);
              return;
            }

            final rawDevices = Map<dynamic, dynamic>.from(devicesValue);
            final devices = <DeviceModel>[];

            rawDevices.forEach((deviceId, deviceData) {
              final id = deviceId.toString();

              if (!allowedDeviceIds.contains(id)) return;

              if (deviceData is Map) {
                devices.add(
                  DeviceModel.fromMap(
                    id,
                    Map<dynamic, dynamic>.from(deviceData),
                  ),
                );
              }
            });

            controller.add(devices);
          },
          onError: controller.addError,
        );
      },
      onError: controller.addError,
    );

    controller.onCancel = () async {
      await userDeviceSub?.cancel();
      await allDevicesSub?.cancel();
    };

    return controller.stream;
  }

  Stream<DeviceModel?> listenDevice(String deviceId) {
    return _devicesRef.child(deviceId).onValue.map((event) {
      final value = event.snapshot.value;

      if (value == null || value is! Map) {
        return null;
      }

      return DeviceModel.fromMap(
        deviceId,
        Map<dynamic, dynamic>.from(value),
      );
    });
  }

  Future<void> addDeviceToCurrentUser({
    required String deviceId,
    String role = 'owner',
    String nickname = 'Smart Switch',
  }) async {
    final uid = currentUid;

    if (uid == null) {
      throw Exception('User not logged in');
    }

    await _usersRef.child(uid).child('devices').child(deviceId).set({
      'role': role,
      'nickname': nickname,
      'active': true,
      'addedAt': ServerValue.timestamp,
    });
  }

  Future<void> setChannelState({
    required String deviceId,
    required String channelId,
    required bool state,
  }) async {
    await _devicesRef.child(deviceId).child('channels').child(channelId).update({
      'state': state,
      'status': state ? 'ON' : 'OFF',
    });
  }

  Future<void> toggleChannel({
    required String deviceId,
    required String channelId,
    required bool currentState,
  }) async {
    await setChannelState(
      deviceId: deviceId,
      channelId: channelId,
      state: !currentState,
    );
  }

  Future<void> startTimer({
    required String deviceId,
    required String channelId,
    required int durationMinutes,
    required String label,
  }) async {
    await _devicesRef.child(deviceId).child('timers').child(channelId).set({
      'enabled': true,
      'durationMinutes': durationMinutes,
      'action': 'OFF',
      'label': label,
      'createdAt': ServerValue.timestamp,
    });
  }

  Future<void> cancelTimer({
    required String deviceId,
    required String channelId,
  }) async {
    await _devicesRef.child(deviceId).child('timers').child(channelId).update({
      'enabled': false,
      'durationMinutes': 0,
      'cancelledAt': ServerValue.timestamp,
    });
  }

  Future<void> saveDailySchedule({
    required String deviceId,
    required String channelId,
    required int onHour,
    required int onMinute,
    required int offHour,
    required int offMinute,
  }) async {
    await _devicesRef.child(deviceId).child('schedules').child(channelId).set({
      'enabled': true,
      'onHour': onHour,
      'onMinute': onMinute,
      'offHour': offHour,
      'offMinute': offMinute,
      'onMinutes': onHour * 60 + onMinute,
      'offMinutes': offHour * 60 + offMinute,
      'repeat': 'daily',
      'updatedAt': ServerValue.timestamp,
    });
  }

  Future<void> cancelSchedule({
    required String deviceId,
    required String channelId,
  }) async {
    await _devicesRef.child(deviceId).child('schedules').child(channelId).update({
      'enabled': false,
      'updatedAt': ServerValue.timestamp,
    });
  }
}