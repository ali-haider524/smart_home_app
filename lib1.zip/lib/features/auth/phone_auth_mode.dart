enum PhoneAuthMode {
  signIn,
  linkToCurrentAccount,
}
